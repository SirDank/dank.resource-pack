----------------[Terms of use]---------------------

You can:
    ✅ Use it in mod packs
    ✅ Use it for Content Creation like YouTube videos (Linking back to this or the other available pages (Modrinth, Planetminecraft, CurseForge))


You cannot:
    ❌ Redistribute edited or unedited assets
    ❌ Re-upload the pack
    ❌ Claim ownership over our assets

These terms may be changed as we deem necessary and at any time.

Versions of this pack before 1.9.2 make use of NegativeSpaces4 resource pack by AmberW/AmberWat which is under Creative Commons Attribution 4.0 International terms.

----------------[Credit]---------------------------


--Pack Creators:--

mr_ch0c0late (Creator and Idea)
    Curse Forge: https://www.curseforge.com/members/mr_ch0c0late1
    Planet Minecraft :https://www.planetminecraft.com/member/mr_ch0c0late1/
    Twitter: https://twitter.com/mr_ch0c0late1

Zartrix (PackDev)

Moggla (Creator of MC Language Formatter)